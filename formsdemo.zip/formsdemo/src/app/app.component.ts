import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { TempFormComponent } from "./components/temp-form/temp-form.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, TempFormComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'formsdemo';
}

export const Constant = {
    VALIDATION_MESSAGE: {
        REQUIRED: 'This is required',
        MIN_LENGTH: 'MIN 3 CHAR REQUIRE'
    }
}
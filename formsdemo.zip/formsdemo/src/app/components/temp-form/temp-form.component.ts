import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Constant } from '../../constants/Constant';
import { JsonPipe } from '@angular/common';

@Component({
  selector: 'app-temp-form',
  standalone: true,
  imports: [FormsModule, RouterModule, JsonPipe],
  templateUrl: './temp-form.component.html',
  styleUrl: './temp-form.component.css'
})
export class TempFormComponent {
  studentObj: any = {
    firstName: '',
    lastName: '',
    userName: '',
    city: '',
    state: '',
    zipCode: '',
    isAcceptTerms: false
  }
  validationMessage: any = Constant.VALIDATION_MESSAGE;
  formValue: any;

  onSubmit() {
    debugger;
    this.formValue = this.studentObj;
  }
  resetForm() {
    this.studentObj = {
      firstName: '',
      lastName: '',
      userName: '',
      city: '',
      state: '',
      zipCode: '',
      isAcceptTerms: false
    }
  }
}
